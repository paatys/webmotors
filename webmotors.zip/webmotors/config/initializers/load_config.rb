WEBMOTORS_CONFIG = YAML.load_file(Rails.root.join('config/webmotors.yml'))[Rails.env]
